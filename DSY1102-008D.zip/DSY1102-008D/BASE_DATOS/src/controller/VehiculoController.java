/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import Bd.Conexion;
import java.util.ArrayList;
import java.util.List;
import models.Vehiculo;

import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author Cetecom
 */
public class VehiculoController {
    Conexion cx;
    helperController helper;

    public VehiculoController() {
        cx = new Conexion();
        cx.conectar();
    }
    
    public List<Vehiculo> listarVehiculos(){
        List<Vehiculo> autos = new ArrayList();
        String query = "SELECT * FROM vehiculo;";
        try {
            ResultSet rs = cx.EjecutarQuery(query);
            while(rs.next()){
                autos.add(new Vehiculo(
                    rs.getString("patente"),
                        rs.getString("marca"),
                        rs.getString("modelo"),
                        rs.getDate("fecha"),
                        rs.getInt("anio")
                ));
            }
            cx.desconectar();
        } catch (Exception e) {
            System.out.println("Error al obtener vehiculos: " + e.getMessage());
        }
        return autos;
    }
    
    public void agregarVehiculo(String patente, String marca, String modelo, Date fecha, int anio){
        String query = "INSERT INTO vehiculo (patente, marca,modelo,fecha,anio) VALUES (?,?,?,?,?) ";
        
        try {
            PreparedStatement st = cx.getConnection().prepareStatement(query);
            st.setString(1,patente);
            st.setString(2,marca);
            st.setString(3, modelo);
            st.setDate(4, new java.sql.Date(fecha.getTime()));
            st.setInt(5, anio);
            st.executeUpdate();
            System.out.println("Vehiculo agregado!");
            helper.showInformation("Vehiculo agregado");
            
        } catch (Exception e) {
            System.out.println("Error al agregar vehiculo : " + e.getMessage());
        }
    }
    
    
    public Vehiculo buscarVehiculo(String patente){
        System.out.println("PATENTEMETODO : " + patente);
        String query = "SELECT * FROM  vehiculo WHERE patente = '" + patente + "';";
        
        System.out.println(query);
        
        try {
            ResultSet rs = cx.EjecutarQuery(query);
            ///System.out.println("NEXT " + rs.next());
            //System.out.println("PATENTE SQL : " + rs.getString("anio"));
            while(rs.next()){
                System.out.println("111111111");
                Vehiculo auto = new Vehiculo(
                        rs.getString("patente"),
                        rs.getString("marca"),
                        rs.getString("modelo"),
                        rs.getDate("fecha"),
                        rs.getInt("anio")
                );
                
                System.out.println("OBJETO: " + auto);
                return auto;
            }
            
        } catch (Exception e) {
            System.out.println("Error al buscar auto: " + e.getMessage());
        }       
        return null;
    }
    
    
    
    public void editarAuto(Vehiculo v){
        
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd-HH:mm:ss");
        String fechaFormateada = sdf.format(v.getFecha());
        
        String query = "UPDATE vehiculo SET marca = '" + v.getMarca() +
                "', modelo = '" + v.getModelo()  + "', fecha = '" 
                + fechaFormateada+ "', anio = " + v.getAnio() + " WHERE patente = '" +
                v.getPatente() + "';";
        System.out.println("QUERY ACTUALIZAR:  " + query );
        
        
        try {
            Statement st = cx.getConnection().createStatement();
            st.executeUpdate(query);
            System.out.println("Vehiculo actualizado");
        } catch (Exception e) {
            System.out.println("Error al actualizar: " + e.getMessage());
        }
    }
    
    
    
    public void eliminarVehiculo(String patente){
        String query = "DELETE FROM vehiculo WHERE patente = '" +  patente +  "';"; 
        
        try {
            if(buscarVehiculo(patente) != null){
                Statement st = cx.getConnection().createStatement();
                st.executeUpdate(query);
                System.out.println("Vehiculo eliminado");
            }else{
                System.out.println("Vehiculo no encontrado, no se puede eliminar");   
            }
        } catch (Exception e) {
            System.out.println("Error al eliminar: " + e.getMessage());
        }
    }
    
}
